#' Function to chant Go Cats
#'
#' @param Chant_in chant we are doing
#' @return message that says "Go Cats"
#'
#' @export

go_cats <- function(){
  # sample function that returns 'go cats'
  # RETURNS: string saying 'go cats'
  return('go cats')
}
